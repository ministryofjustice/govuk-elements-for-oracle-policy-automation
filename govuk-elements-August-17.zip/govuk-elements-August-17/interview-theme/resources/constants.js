const developmentPhase = "Alpha"; //amend for different development stages

const rulebaseName = "LAA"; //amend to rulebase name (probably best if short form used)

//the repeated error text displayed under the next button - if used - is in the CSS file