const developmentPhase = "Alpha"; //amend for different development stages

const rulebaseName = "LAA"; //amend to rulebase name (probably best if short form used)

const hideHiddenButtons = false; //recommended for interviews with a back button on the final page

const highlightErrors = true; //recommended for interviews with long pages requiring scrolling
//the repeated error text displayed under the next button - if used - is in the CSS file

const optionalSuffix = true; //should be left as true (GDS) but if set to false, optional questions will not have (optional) after them

