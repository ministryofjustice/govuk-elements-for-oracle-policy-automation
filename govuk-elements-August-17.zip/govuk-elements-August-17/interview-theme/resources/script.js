function helpExpandCollapse(x) {
	xGranddad = x.parentElement.parentElement;
	if (xGranddad.className.indexOf(" activeHelp") === -1) { //not found = not active
		xGranddad.className += " activeHelp"; //adds the active help class to the grandparent
	} else {
		xGranddad.className = xGranddad.className.substring(0, xGranddad.className.indexOf(" activeHelp")); // this removes the activeHelp class from the granddad
	}
	if (xGranddad.parentElement.getAttribute("role") == "gridcell" && xGranddad.parentElement.tagName == "DIV") { 
		if (xGranddad.parentElement.className.indexOf(" activeHelpPlus") === -1) { //not found = not active
			xGranddad.parentElement.className += " activeHelpPlus"; //adds the active help class to the grandparent's parent
		} else {
			xGranddad.parentElement.className = xGranddad.className.substring(0, xGranddad.className.indexOf(" activeHelpPlus")); // this removes the activeHelpPlus class from the granddad's parent
		}
	}
}

OraclePolicyAutomation.AddExtension({ 
    customHeader: function(interview) {
		return { 
			update: function(el) {
				//to hide "hidden" next buttons - for alignment
				var submitButtons = document.getElementsByClassName("opa-submit");
				for (i=0;i<submitButtons.length;i++) {
					if (submitButtons[i].getAttribute('value') == "Next" && submitButtons[i].style.visibility == "hidden") {
						submitButtons[i].style.display = "none";
					} else {
						submitButtons[i].style.display = "block";
					}
				}
				
			}
		}
	},
	style: {
		control: function(control) {
			if (control.config.caption.indexOf("HideMe") !== -1) { //this hides questions which have "HideMe" (case-sensative) in the question text
				return {
					style: {
						display:"none",
					}
				}
			}
		},
	    question: function(control) {
			if (control.config.caption.indexOf("HideMe") !== -1 || control.config.caption == 'NoLabel') { //this hides questions which have "HideMe" (case-sensative) in the question text
				return {
					style: {
						display:"none",
					}
				}
			}
			if (!control.isMandatory() && control.config.caption != 'NoLabel') { 
				//this gives optional question text the class "optional" - except those which have no label
				return {
					className: "opa-question-optional"
				}
            }
		}
	}
});
