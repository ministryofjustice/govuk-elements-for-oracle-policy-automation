//Constants
const developmentPhase = "Alpha"; //amend for different development stages

const rulebaseName = "LAA"; //amend to rulebase name (probably best if short form used)

const hideHiddenButtons = false; //recommended for interviews with a back button on the final page

const highlightErrors = false; //recommended for interviews with long pages requiring scrolling
//DOES NOT DISPLAY CORRECTLY UNLESS EMBEDDED!!!
//the repeated error text displayed under the next button - if used - is in the CSS file

const optionalSuffix = true; //should be left as true (GDS) but if set to false, optional questions will not have (optional) after them

const disableReadOnlyTabStop = true; //this prevents tab stops from going onto disabled (read only) fields

//This first bit of code sets the dev stage in the banner - the value is set above
if (developmentPhase != "" && typeof(developmentPhase) != 'undefined' && developmentPhase != null) {
	if (typeof(document.getElementsByClassName("phase-tag")[0]) != 'undefined' && document.getElementsByClassName("phase-tag")[0] != null) {
		document.getElementsByClassName("phase-tag")[0].innerHTML = developmentPhase;
	}	
}

//removes "working..." placeholder
if (typeof(document.getElementById("tempContent")) != 'undefined' && document.getElementById("tempContent") != null) {
	document.getElementById("tempContent").innerHTML = "";
}

//This is the JS for the expandable help text
function helpExpandCollapse(x) {
	xGranddad = x.parentElement.parentElement;
	if (xGranddad.className.indexOf(" activeHelp") === -1) { //not found = not active
		xGranddad.className += " activeHelp"; //adds the active help class to the grandparent
	} else {
		xGranddad.className = xGranddad.className.substring(0, xGranddad.className.indexOf(" activeHelp")); // this removes the activeHelp class from the granddad
	}
	if (xGranddad.parentElement.getAttribute("role") == "gridcell" && xGranddad.parentElement.tagName == "DIV") { 
		if (xGranddad.parentElement.className.indexOf(" activeHelpPlus") === -1) { //not found = not active
			xGranddad.parentElement.className += " activeHelpPlus"; //adds the active help class to the grandparent's parent
		} else {
			xGranddad.parentElement.className = xGranddad.className.substring(0, xGranddad.className.indexOf(" activeHelpPlus")); // this removes the activeHelpPlus class from the granddad's parent
		}
	}
}

OraclePolicyAutomation.AddExtension({ 
    customHeader: function(interview) {
		var buttonText = [];
		var oldTitleName = "";
		return { 
			update: function(el) {
			    ///THIS IS FOR THE CHECK YOUR ANSWERS SCREEN
				var numberScreens = (interview.getScreens().length)-1;
				if(interview.getScreens()[numberScreens].caption.substring(0,18) == "Check your answers") { 
				//we use substring here to account for different screen names - it needs to start "Check your answers"
					for (i=0;i<=numberScreens;i++) {
						//for each screen
						var screenName = interview.getScreens()[i].caption.replace(/\s/g, "-"); //we replace the spaces with hyphens - screen names line "Your details" changed to "Your-details"
						var screenLink = interview.getScreens()[i].investigateUri.replace("JSONInvestigate", "investigate"); //this is the link for each screen in the array - we replace some of the text so it works
						var changeLinks = document.getElementsByClassName("screen_"+screenName); //this gets all links on the page which relate to said screen.
						for (j=0;j<changeLinks.length;j++) { //for each screen in array
							//for each class (link) which points to said screen
							if (typeof(changeLinks[j].getElementsByTagName("a")[0]) != 'undefined' && changeLinks[j].getElementsByTagName("a")[0] != null) {
								//this changes the hrefs for all instances where the class of the link matches (i.e. it points to this screen)
								changeLinks[j].getElementsByTagName("a")[0].href = screenLink;
								//goes through all links in the elements relating to this screen and changes the href to link to them
							}
						}
					}
				}
				if (interview.getStages().length) {
					//in this situation the CYA screen won't work!
					//we replace the "Change" with "Restart"
					var unlinkedLinks = document.querySelectorAll(".checkAnswers a[href='#']")
					for (k=0;k<unlinkedLinks.length;k++) {
						//we change (below) the text of both spans in the link - the first is visible and the second is for accessibility
						unlinkedLinks[k].querySelector("span.visually-visible").innerHTML = "Go to start";
						unlinkedLinks[k].querySelector("span.visually-hidden").innerHTML = " to change" + unlinkedLinks[k].querySelector("span.visually-hidden").innerHTML
						unlinkedLinks[k].href = interview.getStages()[0].investigateUri.replace("JSONInvestigate", "investigate");;
					}
				}
				///END OF CHECK YOUR ANSWERS SCRIPT
				
				
				///STAGE BANNER
				if(typeof(document.querySelector("#interview header[role=banner]")) != 'undefined' && document.querySelector("#interview header[role=banner]") != null) {
					var phaseBannerText = '<span class="devPhase">'+developmentPhase+'</span> This is a new service &ndash; your <a id="feedbackLink" href="" target="_blank">feedback</a><span class="visuallyhidden">(Opens in a new window)</span> will help us to improve it.';
					document.querySelector("#interview header[role=banner]").innerHTML = phaseBannerText;
				}
				///END OF STAGE BANNER
				
				///BACK BUTTON TAB INDEX
				if(typeof(document.querySelector("button[restylekey=backButton]")) != 'undefined' && document.querySelector("button[restylekey=backButton]") != null) {
					document.querySelector("button[restylekey=backButton]").tabIndex = 2;
				}
				if(typeof(document.querySelector("#feedbackLink")) != 'undefined' && document.querySelector("#feedbackLink") != null) {
					document.querySelector("#feedbackLink").tabIndex = 1;
				}
				//this bit of text sets the button to be first in the tab order - this is because it appears at the top of the screen now.
				///END OF BACK BUTTON TAB INDEX
				
				//a few things used by multiple bits of code
				var title = document.getElementsByClassName("opa-screen-title")[0];
				var titleName = title.getElementsByTagName("span")[0].innerHTML;
				var submitButtons = document.getElementsByClassName("opa-submit");
				
				//adds a dynamic title - "needed" for embedded rulebases
					var titleHeader = document.getElementsByTagName("title")[0];
					titleHeader.innerHTML = titleName + " | " + rulebaseName;
				
				///POP-UP-QUESTION CLASS
				var popUps = document.getElementsByClassName("pop-up-question")
				for (i=0;i<popUps.length;i++) { 
					popUps[i].parentElement.parentElement.parentElement.parentElement.className += " pop-up";
				}
				///END OF POP-UP-QUESTION CLASS
				
				
				//checks for errors to repeat next to next button
				//this will include both rule errors and question errors 
				if (typeof(highlightErrors) != 'undefined' && highlightErrors != null && highlightErrors == true) {
					if (highlightErrors==true) {
						if (document.getElementsByClassName("opa-interview-controls")[0].getElementsByTagName("div")[0].getElementsByClassName("opa-error-text").length > 0) {
							//this checks for erros in the div which contains all the questions on one page - any higher causes errors on other pages to be included
							var error = true;
						} else {
							var error = false;
						}
						//to outline next buttons in red if errors on page 
						var submitButtons = document.getElementsByClassName("opa-submit");
						for (i=0;i<submitButtons.length;i++) {
							var thisButton = submitButtons[i];
							thisButton.className = thisButton.className.replace(" errorButton","");
							//thisButton.parentElement.parentElement.className = thisButton.parentElement.parentElement.className.replace(" errorReminder","");
							document.getElementsByClassName("opa-interview-controls")[0].className = document.getElementsByClassName("opa-interview-controls")[0].className.replace(" errorReminder","");
							//removes all added classes then adds them again if needed.
							if (error) {
								thisButton.className += " errorButton"; //class added to all buttons (only affects those of tag <input> in reality)
								thisButton.parentElement.parentElement.className += " errorReminder"; //class added to overall page (for error text beheath buttons)
								thisButton.blur(); // stops focus - otherwise it looks crap in IE
							} 
						}
					}
				}
				if (typeof(hideHiddenButtons) != 'undefined' && hideHiddenButtons != null && hideHiddenButtons==true) {
				//to hide "hidden" next buttons - for alignment
				//(this is only needed if the final page has a back button)
					for (i=0;i<submitButtons.length;i++) {
						var thisButton = submitButtons[i];
						if (thisButton.style.visibility == "hidden") {
							thisButton.style.display = "none"; //this removes the button completly, so it doesn't push stuff over.
						} else {
							thisButton.style.display = "block"; //this restores the styling should it have been removed by the above (and then one goes back)
						}
					}
				}
				if (typeof(disableReadOnlyTabStop) != 'undefined' && disableReadOnlyTabStop != null && disableReadOnlyTabStop==true) {
					//disables tab stops for disabled fields
					var readOnlyArray = document.getElementsByClassName("opa-disabled-field");
					for (i=0;i<readOnlyArray.length;i++) {
						readOnlyArray[i].getElementsByTagName("input")[0].tabIndex = "-1";
					}
				}
				//to move back button to top
			//	if (typeof(document.querySelector("button[restylekey=backButton]")) != 'undefined' && document.querySelector("button[restylekey=backButton]") != null) {
			//		var backButtons = document.querySelectorAll("button[restylekey=backButton]");
			//		var backButton = backButtons[0];
			//		var titleBlock = document.getElementsByClassName("opa-screen-title-block")[0];
			//		if (backButtons.length == 1) {
			//			titleBlock.outerHTML = backButton.outerHTML + titleBlock.outerHTML; // add back button here
			//			backButton.style.display = "none";
			//		}
			//		for (i=1;i<backButtons.length;i++) {
			//			backButtons[i].visibility = "hidden";
			//		}
			//	}
				
				//START PAGE START BUTTON ARROW (APPLY CLASS HERE - CSS DOES ARROW)
				if (typeof(document.querySelectorAll(".opa-submit[value='Start now']")[0]) != 'undefined' && document.querySelectorAll(".opa-submit[value='Start now']")[0]) {
					document.querySelectorAll(".opa-submit[value='Start now']")[0].parentElement.className += "startButton";
				}
					//end of JS titbits
			}
		}
	},
	style: {
		control: function(control) {
			if (control.config.caption.indexOf("HideMe") !== -1) { //this hides questions which have "HideMe" (case-sensative) in the question text
				return {
					style: {
						display:"none",
					}
				}
			}
			if (control.isReadOnly()) {
				return {
					className: "opa-disabled-field"
				}
			}
		},
	    question: function(control) {
			if (control.config.caption.indexOf("HideMe") !== -1 || control.config.caption == 'NoLabel') { //this hides questions which have "HideMe" (case-sensative) in the question text
				return {
					style: {
						display:"none",
					}
				}
			}
			if (typeof(optionalSuffix) == 'undefined' || optionalSuffix == null || optionalSuffix == true) {
				if (!control.isMandatory() && !control.isReadOnly() && control.config.caption != 'NoLabel') { 
					//this gives optional question text the class "optional" - except those which have no label (their label is "NoLabel")
					return {
						className: "opa-question-optional"
					}
				}
			}
			
		}
	}
});

