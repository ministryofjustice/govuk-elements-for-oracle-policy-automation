//Constants - these configure the rulebase 

//Change to your departmental colour
const departmentColour = "#57da95"; //for development - blog.gov.uk colour
//const departmentColour = "#005EA5"; //Override - LAA always uses GDS blue
//const departmentColour = "#5A5C92"; //This is the specific departmental colour for the bar along the top

//Change to Alpha/Beta etc
const developmentPhase = "Development";

//Short name for the rulebase - initials or something short that is good
const rulebaseName = "RulebaseName";

const feedbackRulebaseName = "RulebaseName"; //name used by feedback form

//Do you want errors to be highlighted (experimental feature - not tested)
const highlightErrors = false; //recommended for interviews with long pages requiring scrolling
//the repeated error text displayed under the next button - if used - is in the CSS file

//do you want "(optional)" to automatically appear after optional questions?  
//if you set this to False - you'll have to add "(optional)" manually - or override it per question with custom property.
const optionalSuffix = true; 

const disableReadOnlyTabStop = true; //this prevents tab stops from going onto disabled (read only) fields

//the href/mailto link for feedback
//const feedbackLinkAddress = "mailto:xxxxxx?subject=Feedback%20on%20the%20LAA%20form";
const feedbackLinkAddress = "https://forms.legalservices.gov.uk/public/web-determinations/startsession/FeedbackForm";
//note: the seed data is re-applied every screen (code below)

//this is to test whether we are on GOV.UK or not
var domainName = "normal";
if (window.location.href.indexOf("www.gov.uk") >= 0 || window.location.href.indexOf("service.gov.uk") >= 0 || window.location.href.indexOf("blog.gov.uk") >= 0) {
	domainName = "special";
} 

///GDS date format
//First set the day/month/year to English
var dayText = "Day";
var monthText = "Month";
var yearText = "Year";

//Then change to Welsh if needed
if (window.location.href.indexOf("/cy-GB") >= 0) {
	dayText = "Dydd";
	monthText = "Mis";
	yearText = "Blwyddyn";
} 

//favicon
document.getElementsByTagName("head")[0].innerHTML +='<link rel="shortcut icon" href="${resources-root}/images/favicon.ico" type="image/x-icon" />';
document.getElementsByTagName("head")[0].innerHTML +='<link rel="mask-icon" href="${resources-root}/images/gov.uk_logotype_crown.svg" color="#0b0c0c">';
document.getElementsByTagName("head")[0].innerHTML +='<link rel="apple-touch-icon" sizes="180x180" href="${resources-root}/images/apple-touch-icon.png">';
document.getElementsByTagName("head")[0].innerHTML +='<link rel="apple-touch-icon" sizes="167x167" href="${resources-root}/images/apple-touch-icon.png">';
document.getElementsByTagName("head")[0].innerHTML +='<link rel="apple-touch-icon" sizes="152x152" href="${resources-root}/images/apple-touch-icon.png">';
document.getElementsByTagName("head")[0].innerHTML +='<link rel="apple-touch-icon" href="${resources-root}/images/apple-touch-icon.png">';

///feedback link - screen name
var feedbackScreenName;
				
$(document).ready(function(){
	$("header[role=banner]").load("${resources-root}/html/header.html",function(){
		if (domainName != "special") {
			$("link[href*=\"ntafont.css\"]").remove();
			$(".phase-banner").css({"border-top-color": departmentColour});;
		} else {
			$(".header-logo").addClass("special");
			$("a#logo").html("GOV.UK");
			$("a#logo").prop("href", "https://www.gov.uk");
			$("a#logo").prop("title", "Go to the GOV.UK homepage");
		}
		$(".phase-tag").html(developmentPhase);
		if (feedbackLinkAddress.toUpperCase().indexOf("MAILTO") == 0) {
			//if the feedback link is a mailto, we change the accessibility description
			$("#feedback-clarification").html("(Opens an email)"); //this overrides the default in header.html, which says (opens in a new window)
			$("#feedback-link").prop("href", feedbackLinkAddress+'&body=Please find below some feedback regarding the online form.%0D%0A%0D%0AFeedback:');
		} else {
			//if the feedback is not a mailto, it is an href to the feedback form.  We add seed data to give more info.  
			$("#feedback-link").prop("href", feedbackLinkAddress + '?seedData=%7b_URL_PARENT_FORM_NAME_PARAM:"'+feedbackRulebaseName+'",_URL_PARENT_FORM_SCREEN_PARAM:"First screen"%7d');
			//the default for screen reached is "not reached anything" (essentially), and this is overridden below - including on the first screen.
		}
	});
	//applies custom header
	
	$(".opa-footer-left").load("${resources-root}/html/footerleft.html");
	$(".opa-footer-right").load("${resources-root}/html/footerright.html");
	//applies custom footer

	//this bit decides whether to apply GOV.UK styling or the permitted non-gov.uk styling
});



//removes "working..." placeholder
if (typeof(document.getElementById("tempContent")) != 'undefined' && document.getElementById("tempContent") != null) {
	document.getElementById("tempContent").innerHTML = "";
}

//This is the JS for the expandable help text
function helpExpandCollapse(x) {
	xGranddad = x.parentElement.parentElement;
	if (xGranddad.className.indexOf(" activeHelp") === -1) { //not found = not active
		xGranddad.className += " activeHelp"; //adds the active help class to the grandparent
	} else {
		xGranddad.className = xGranddad.className.substring(0, xGranddad.className.indexOf(" activeHelp")); // this removes the activeHelp class from the granddad
	}
	if (xGranddad.parentElement.getAttribute("role") == "gridcell" && xGranddad.parentElement.tagName == "DIV") { 
		if (xGranddad.parentElement.className.indexOf(" activeHelpPlus") === -1) { //not found = not active
			xGranddad.parentElement.className += " activeHelpPlus"; //adds the active help class to the grandparent's parent
		} else {
			xGranddad.parentElement.className = xGranddad.className.substring(0, xGranddad.className.indexOf(" activeHelpPlus")); // this removes the activeHelpPlus class from the granddad's parent
		}
	}
}

///Function to transfer the three text boxes into the one date text box...
function getDate(x,y,z){
	//x=day/month/year; y=this; z=real date field
	if (x=="d") {
		var output = y.value+"/"+y.nextSibling.value+"/"+y.nextSibling.nextSibling.value;
	}
	if (x=="m") {
		var output = y.previousSibling.value+"/"+y.value+"/"+y.nextSibling.value;
	}
	if (x=="y") {
		var output = y.previousSibling.previousSibling.value+"/"+y.previousSibling.value+"/"+y.value;
	}
	var dateArray = output.split("/");
	if (z.value != output && dateArray[0] != "" && dateArray[1] != "" && dateArray[2] != "") {
		var a = document.activeElement;
		z.focus();
		z.value = output;
		if ('fireEvent' in z)
			z.fireEvent("onchange");
		else {
			var evt = document.createEvent("HTMLEvents");
			evt.initEvent("change", false, true);
			z.dispatchEvent(evt);
		}
		a.focus();
	}
}

OraclePolicyAutomation.AddExtension({ 
    customQuestionText: function(control) {
		return {
			//this mount bit deals with optional tags.
			//if switched on (above) the optional tag will appear after the question.  
			//will not add optional suffix to Radio Buttons or if custom property = optional:hide
			//it will also add a class to date questions
			//a property of hide:hide will hide the question, but leave the label
			mount: function(el) {
				///amends feedback link for each screen
				feedbackScreenName = $(".opa-screen-title").text();
				feedbackScreenName = feedbackScreenName.split(' ').join('%20');
				if (feedbackLinkAddress.toUpperCase().indexOf("MAILTO") == 0) {
					//if the feedback link is a mailto, we add a bit to the mail body
					$("#feedback-link").prop("href", feedbackLinkAddress+'&body=Please find below some feedback regarding the online form.%0D%0A%0D%0APage reached: '+feedbackScreenName+'%0D%0A%0D%0AFeedback:');
				} else {
					//if the feedback link is not a mailto, we add a bit to the seed data
					$("#feedback-link").prop("href", feedbackLinkAddress + '?seedData=%7b_URL_PARENT_FORM_NAME_PARAM:"'+feedbackRulebaseName+'",_URL_PARENT_FORM_SCREEN_PARAM:"'+feedbackScreenName+'"%7d');
				}//the above gets the screen title for the feedback, and replaces all spaces with %20s.  
				
				
				var label = document.createElement("span");
				if (control.getProperty("label") === "hide") {
					//puts question text inside span a hidden span, inside the above span
					label.innerHTML = '<span class="visually-hidden">'+control.getCaption()+'</span>'; 
				} else {
					//puts question text inside the span
					label.innerHTML = control.getCaption(); 
				}
				if (control.getProperty("pop-up") === "pop-up") {
					el.parentElement.parentElement.parentElement.className += " pop-up"
				}
				if (control.getProperty("date") === "GDS") {
					label.setAttribute("class","gds-date-question gds-question-text");
				} else {
					label.setAttribute("class","gds-question-text");					
				}
				//This (below) might not work!!! :(
				if (control.getProperty("optional") !== "hide" && control.getProperty("label") !== "hide" && !control.isMandatory() && !control.isReadOnly() && control.getCaption() != 'NoLabel') {
					//condition 1: not set to hide; not mandatory; not read only; question text not "NoLabel"
					if ((optionalSuffix || control.getProperty("optional") === "show") && control._source.config.controlType != "Radiobutton") {
						label.innerHTML += '<span class="optional-suffix"> (optional)</span>';
					}
				}
				if (typeof(control._source.config.hintText)!='undefined' && control._source.config.hintText!= null && control._source.config.hintText.length > 0) {
					label.innerHTML += "<br /><span class='hint-text'>"+control._source.config.hintText+"</span>";
				} 
				if (control.getProperty("label") !== "blank") {
					el.appendChild(label);
				}
			},
			//this update bit deals with error messages - positioning them where GDS intended.
			update: function(el) {
				//below applies class to pop-up marked questions
				if (control.getProperty("pop-up") === "pop-up") {
					el.parentElement.parentElement.parentElement.className += " pop-up"
				}
				var umbrella = el.parentElement.parentElement.parentElement;
				//we need to check that (a) an error exists, and (b) that it isn't overflow:hidden.
				//if it is overflow hidden, the error message is not displayed - so we don't do anything.
				if (umbrella.getElementsByClassName("opa-error").length > 0 && umbrella.getElementsByClassName("opa-error")[0].style.overflow != "hidden") {
					var errorArray = umbrella.getElementsByClassName("opa-error-text");
					var errorPositioned = el.getElementsByClassName("gds-error");
					var errorBreaks = el.getElementsByClassName("error-break");
					if (errorArray.length > 0 && errorPositioned.length == 0) {
						el.innerHTML += '<br class="error-break"/><span class="gds-error">'+errorArray[0].innerHTML+'</span>';
						errorArray[0].style.display = "none";
					} else if (errorArray.length == 0 && errorPositioned.length > 0) {
						errorPositioned[0].outerHTML = "";
						errorBreaks[0].outerHTML = "";
					}
				}
			}
		}
	},
/*	customInput: function(control) {
	//	console.log(Object.getOwnPropertyNames(control._source));
	//	console.log(Object.getOwnPropertyNames(control.getOptions()));
	//	console.log(Object.getOwnPropertyNames(control.getCaption()));
	//	console.log(control._source.config.controlType);
	//	console.log(control._source.config.attributeId);
	//	console.log(control.id);
	//	console.log(control);
		if (control.getProperty("date") === "xxx") {
			return {
				mount: function(el) {
					var currentValue = control.getValue();
					var d = document.createElement("input");
					var m = document.createElement("input");
					var y = document.createElement("input");
					if (typeof(currentValue) != 'undefined' && currentValue != null) {
						var defaultValue = currentValue.split("-");
						d.setAttribute("value",defaultValue[2]);
						m.setAttribute("value",defaultValue[1]);
						y.setAttribute("value",defaultValue[0]);
					} 
					d.setAttribute("id",control.id+"Day");
					m.setAttribute("id",control.id+"Month");
					y.setAttribute("id",control.id+"Year");
					d.setAttribute("type","text");
					m.setAttribute("type","text");
					y.setAttribute("type","text");
					d.setAttribute("style","outline: rgb(114, 119, 128) solid 1px; outline-offset: 0px; border: 0px; padding: 0.4em 2em 0.4em 0.8em; box-sizing: content-box; width: 24px; font-family: inherit; font-size: inherit; font-weight: inherit; font-style: inherit; color: inherit;");
					m.setAttribute("style","outline: rgb(114, 119, 128) solid 1px; outline-offset: 0px; border: 0px; padding: 0.4em 2em 0.4em 0.8em; box-sizing: content-box; width: 24px; font-family: inherit; font-size: inherit; font-weight: inherit; font-style: inherit; color: inherit;");
					y.setAttribute("style","outline: rgb(114, 119, 128) solid 1px; outline-offset: 0px; border: 0px; padding: 0.4em 2em 0.4em 0.8em; box-sizing: content-box; width: 48px; font-family: inherit; font-size: inherit; font-weight: inherit; font-style: inherit; color: inherit;");
					
				//	var errTxt = "";
				//	x.innerHTML = control.getCaption();
				//	x.innerHTML = JSON.stringify(control);
					
					el.appendChild(d);
					el.appendChild(m);
					el.appendChild(y);
				},
				unmount: function(el) {
					var day = document.getElementById(control.id+"Day");
					var month = document.getElementById(control.id+"Month");
					var year = document.getElementById(control.id+"Year");
					var value = year.value+"-"+month.value+"-"+day.value
					console.log("unmount: "+value);
					control.setValue(value);
				},
				update: function(el) {
					var day = document.getElementById(control.id+"Day");
					var month = document.getElementById(control.id+"Month");
					var year = document.getElementById(control.id+"Year");
					var value = year.value+"-"+month.value+"-"+day.value
					console.log("unmount: "+value);
					control.setValue(value);
				}
			
			}
			
		}
	},
*/	customHeader: function(interview) {
		var buttonText = [];
		var oldTitleName = "";
		return { 
			update: function(el) {
				///THIS IS TO ADD SCREEN READER COMPATIBILITY TO RADIO BUTTONS.
				///FOLLOWING FEEDBACK THAT SAID THESE WERE NOT READ OUT
				var radioOptions = document.querySelectorAll(".opa-radio-container>span");
				for (i=0;i<radioOptions.length;i++) {
					radioOptions[i].setAttribute("aria-label", radioOptions[i].innerHTML);
				}
				
				
				///THIS IS FOR THE CHECK YOUR ANSWERS SCREEN
				var numberScreens = (interview.getScreens().length)-1; //the number of screens encountered so far minus 1 (starting from 0)
				//we use substring here to account for different screen names - it needs to start "Check your answers"
				if(interview.getScreens()[numberScreens].caption.substring(0,18) == "Check your answers") {	
					//the first thing we do is remove spaces from the class name.  
					//the class name should be cya-change (1 space) screen_then-screen-name-with-hyphens

					var allChangeLinkTags = document.getElementsByTagName("dd");
					if(typeof(allChangeLinkTags[0]) != 'undefined' && allChangeLinkTags[0] != null) { //if at least one exists
						for (i=0;i<allChangeLinkTags.length;i++) {
							if (allChangeLinkTags[i].className.substr(0,10) == "cya-change") { //if the dd tag starts with class="cya-change" !!NOTE: we cannot use getElementsByClassName because we are manipulating the class here
								allChangeLinkTags[i].className = allChangeLinkTags[i].className.replace("'", "’");
								//change all apostrophes in class name for smart apostrophe (normal single blips cause issues)
								allChangeLinkTags[i].className = allChangeLinkTags[i].className.replace(/\s/g, "-");
								//change all spaces in class name for hyphens
								allChangeLinkTags[i].className = allChangeLinkTags[i].className.replace("cya-change-", "cya-change ");
								//turn the one space that is meant to be there back to a space
							}
						}
					}
					for (i=0;i<=numberScreens;i++) {
						//for each screen so far
						var screenName = interview.getScreens()[i].caption; 
						//get screen title
						screenName = screenName.replace(/\s/g, "-"); //... we replace the spaces with hyphens - screen names line "Your details" changed to "Your-details"
						//deal with spaces
						screenName = screenName.replace("'", "’").replace("&#39;", "’"); //... we replace the apostrophes with smart quote - screen names line "Mike's-details" changed to "Mike’s-details"
						//deal with apostrophes
						var screenLinkUri = interview.getScreens()[i].investigateUri;
						//get link for screen
						var changeLinks = document.getElementsByClassName("screen_"+screenName); //this gets all links on the page which relate to said screen. We replace spaces and apostrophes with hyphens and smart quotes to catch dynamic screen names which might have spaces in them.
						//get element which refers to that screen
						for (j=0;j<changeLinks.length;j++) { //for each screen in array
							changeLinks[j].linkUri = screenLinkUri;	
							//set the URI to a property of this object
							if (changeLinks[j].addEventListener) {
								changeLinks[j].addEventListener("click",function(clk) {interview.navigate(this.linkUri);clk.preventDefault();},false);
							} else {
								changeLinks[j].attachEvent("onclick", function(clk) {interview.navigate(this.linkUri);clk.preventDefault();});
							}
							//add the onclick event
							changeLinks[j].getElementsByTagName("a")[0].href = "#link-to"+screenName;
						}
					}
				}
				
				//this bit is a catch-all for if the links are broken for some reason
				if (interview.getStages().length > 1) {
					//in this situation the CYA screen won't work!
					//we replace the "Change" with "Restart"
					var unlinkedLinks = document.querySelectorAll(".checkAnswers a[href='#']")
					for (k=0;k<unlinkedLinks.length;k++) {
						//we change (below) the text of both spans in the link - the first is visible and the second is for accessibility
						unlinkedLinks[k].querySelector("span.visually-visible").innerHTML = "Go to start";
						unlinkedLinks[k].querySelector("span.visually-hidden").innerHTML = " to change" + unlinkedLinks[k].querySelector("span.visually-hidden").innerHTML
						if (unlinkedLinks[k].addEventListener) {
							unlinkedLinks[k].addEventListener("click",function(clk) {interview.navigate(interview.getStages()[0].investigateUri);clk.preventDefault();},false);
						} else {
							unlinkedLinks[k].attachEvent("onclick", function(clk) {interview.navigate(interview.getStages()[0].investigateUri);clk.preventDefault();});
						}
					}
				}
				
				///END OF CHECK YOUR ANSWERS SCRIPT
				
				///BACK BUTTON TAB INDEX
				if(typeof(document.querySelector("button[restylekey=backButton]")) != 'undefined' && document.querySelector("button[restylekey=backButton]") != null) {
					document.querySelector("button[restylekey=backButton]").tabIndex = 2;
				}
				if(typeof(document.querySelector("#feedbackLink")) != 'undefined' && document.querySelector("#feedbackLink") != null) {
					document.querySelector("#feedbackLink").tabIndex = 1;
				}
				//this bit of text sets the button to be first in the tab order - this is because it appears at the top of the screen now.
				///END OF BACK BUTTON TAB INDEX
				
				//a few things used by multiple bits of code
				var title = document.getElementsByClassName("opa-screen-title")[0];
				var titleName = title.getElementsByTagName("span")[0].innerHTML;
				var submitButtons = document.getElementsByClassName("opa-submit");
				
				//adds a dynamic title - "needed" for embedded rulebases
					var titleHeader = document.getElementsByTagName("title")[0];
					titleHeader.innerHTML = titleName + " | " + rulebaseName;
				
				
				
				//checks for errors to repeat next to next button
				//this will include both rule errors and question errors 
				if (typeof(highlightErrors) != 'undefined' && highlightErrors != null && highlightErrors == true) {
					if (highlightErrors==true) {
						if (document.getElementsByClassName("opa-interview-controls")[0].getElementsByTagName("div")[0].getElementsByClassName("opa-error-text").length > 0) {
							//this checks for erros in the div which contains all the questions on one page - any higher causes errors on other pages to be included
							var error = true;
						} else {
							var error = false;
						}
						//to outline next buttons in red if errors on page 
						var submitButtons = document.getElementsByClassName("opa-submit");
						for (i=0;i<submitButtons.length;i++) {
							var thisButton = submitButtons[i];
							thisButton.className = thisButton.className.replace(" errorButton","");
							//thisButton.parentElement.parentElement.className = thisButton.parentElement.parentElement.className.replace(" errorReminder","");
							document.getElementsByClassName("opa-interview-controls")[0].className = document.getElementsByClassName("opa-interview-controls")[0].className.replace(" errorReminder","");
							//removes all added classes then adds them again if needed.
							if (error) {
								thisButton.className += " errorButton"; //class added to all buttons (only affects those of tag <input> in reality)
								thisButton.parentElement.parentElement.className += " errorReminder"; //class added to overall page (for error text beheath buttons)
								thisButton.blur(); // stops focus - otherwise it looks crap in IE
							} 
						}
					}
				}
				if (typeof(disableReadOnlyTabStop) != 'undefined' && disableReadOnlyTabStop != null && disableReadOnlyTabStop==true) {
					//disables tab stops for info only fields
					var readOnlyArray = document.getElementsByClassName("gds-information");
					for (i=0;i<readOnlyArray.length;i++) {
						readOnlyArray[i].getElementsByTagName("input")[0].tabIndex = "-1";
					}
				}
				var dateTriggers = document.getElementsByClassName("gds-date-question");
				if (dateTriggers.length > 0) {
					for (i=0;i<dateTriggers.length;i++) {
						var ctrlId = dateTriggers[i].parentElement.parentElement.getAttribute("for"); //gets the ID of the control
						var ctrlNumber = ctrlId.replace("opmCtl", ""); //gets the number of the control (e.g. opmCtl10 would be 10)
						//console.log(ctrlNumber);
						if (document.getElementsByClassName('dateInputDay '+ctrlNumber).length == 0) {
							var ctrl = document.getElementById(ctrlId); //styles actual input box
							ctrl.setAttribute("tabindex", "-1");
							var ctrlParent = ctrl.parentElement;
							ctrlParent.style.width = "0";
							ctrlParent.style.padding = "0";
							ctrlParent.style.overflow = "hidden";
							
							if (ctrl.value!="") {
								var existingDate = ctrl.value.split("/");
							} else {
								var existingDate = "//".split("/");
							}
							var dateInputBoxes = '<br />';
							dateInputBoxes += '<div class="new-error laa-err'+ctrlNumber+'"></div>';
							dateInputBoxes += '<div class="dayContainer"><label aria-label="'+dayText+'" for="day'+ctrlNumber+'">'+dayText+'</label></div>';
							dateInputBoxes += '<div class="monthContainer"><label aria-label="'+monthText+'" for="month'+ctrlNumber+'">'+monthText+'</label></div>';
							dateInputBoxes += '<div class="yearContainer"><label aria-label="'+yearText+'" for="year'+ctrlNumber+'">'+yearText+'</label></div>';
							dateInputBoxes += '<br /><input class="dateInputDay '+ctrlNumber+'" id="day'+ctrlNumber+'" type="text" onblur=\'getDate("d",this,document.getElementById("'+ctrlId+'"))\' value="'+existingDate[0]+'" maxlength="2"/>';
							dateInputBoxes += '<input class="dateInputMonth '+ctrlNumber+'" id="month'+ctrlNumber+'"  type="text" onblur=\'getDate("m",this,document.getElementById("'+ctrlId+'"))\' value="'+existingDate[1]+'" maxlength="2"/>';
							dateInputBoxes += '<input class="dateInputYear '+ctrlNumber+'" id="year'+ctrlNumber+'"  type="text" onblur=\'getDate("y",this,document.getElementById("'+ctrlId+'"))\' value="'+existingDate[2]+'" maxlength="4"/>';
							dateTriggers[i].outerHTML += dateInputBoxes;
							
						}
						var oldErrMsg = document.getElementById("opa-err"+ctrlNumber);
						var newErrMsg = document.getElementsByClassName("laa-err"+ctrlNumber)[0];
						if (oldErrMsg !== null){ //if error for this exists.
							newErrMsg.innerHTML=oldErrMsg.innerHTML; //copies text from original error message
							newErrMsg.setAttribute("style",oldErrMsg.parentElement.style.cssText); //copies style from original error message
							oldErrMsg.style.display = "none"; //hides original
						}
					}
				} 
				
				//START PAGE START BUTTON ARROW (APPLY CLASS HERE - CSS DOES ARROW)
				if (typeof(document.querySelectorAll(".opa-submit[value='Start now']")[0]) != 'undefined' && document.querySelectorAll(".opa-submit[value='Start now']")[0]) {
					document.querySelectorAll(".opa-submit[value='Start now']")[0].parentElement.className += "startButton";
				}
				
				//This adjusts the position of the (absolutely positioned) back button based on the height of the header.
				var headerHeight = ($('header[role="banner"]').outerHeight(true))+11;
				$('button[restylekey="backButton"]').css("top",headerHeight+"px");
				//console.log($('button[restylekey="backButton"]'));
			

				//end of JS titbits
			}
		}
	},
	style: {
		control: function(control) {
			//this hides questions which have "HideMe" (case-sensative) in the question text (legacy)
			//or if questions have hide = hidden
			if (control.config.caption.indexOf("HideMe") !== -1 || control.getProperty("hide") === "hidden") { 
				return {
					style: {
						display:"none",
					}
				}
			}
			if (control.getProperty("type") === "info") {
				// this adds a class which causes the answer to not have a tab stop
				return {
					className: "gds-information"
				}
			}
		},
	    question: function(control) {
			//this hides questions which have "HideMe" (case-sensative) in the question text (legacy)
			//or if questions have hide = hidden
			if (control.config.caption.indexOf("HideMe") !== -1 || control.getProperty("hide") === "hidden") { 
				return {
					style: {
						display:"none",
					}
				}
			}
		}
	}
});

