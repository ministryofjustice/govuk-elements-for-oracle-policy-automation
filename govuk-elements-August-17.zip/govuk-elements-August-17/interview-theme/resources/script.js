//This first bit of code sets the dev stage in the banner - the value is set in constants.js
if (developmentPhase != "" && developmentPhase != 'undefined' && developmentPhase != null) {
	if (typeof(document.getElementsByClassName("phase-tag")[0]) != 'undefined' && document.getElementsByClassName("phase-tag")[0] != null) {
		document.getElementsByClassName("phase-tag")[0].innerHTML = developmentPhase;
	}	
}

//This is the JS for the expandable help text
function helpExpandCollapse(x) {
	xGranddad = x.parentElement.parentElement;
	if (xGranddad.className.indexOf(" activeHelp") === -1) { //not found = not active
		xGranddad.className += " activeHelp"; //adds the active help class to the grandparent
	} else {
		xGranddad.className = xGranddad.className.substring(0, xGranddad.className.indexOf(" activeHelp")); // this removes the activeHelp class from the granddad
	}
	if (xGranddad.parentElement.getAttribute("role") == "gridcell" && xGranddad.parentElement.tagName == "DIV") { 
		if (xGranddad.parentElement.className.indexOf(" activeHelpPlus") === -1) { //not found = not active
			xGranddad.parentElement.className += " activeHelpPlus"; //adds the active help class to the grandparent's parent
		} else {
			xGranddad.parentElement.className = xGranddad.className.substring(0, xGranddad.className.indexOf(" activeHelpPlus")); // this removes the activeHelpPlus class from the granddad's parent
		}
	}
}

OraclePolicyAutomation.AddExtension({ 
    customHeader: function(interview) {
		var buttonText = [];
		var oldTitleName = "";
		return { 
			update: function(el) {
				//a few things used by multiple bits of code
				var title = document.getElementsByClassName("opa-screen-title")[0];
				var titleName = title.getElementsByTagName("span")[0].innerHTML;
				var submitButtons = document.getElementsByClassName("opa-submit");
				
				//adds a dynamic title - "needed" for embedded rulebases
					var titleHeader = document.getElementsByTagName("title")[0];
					titleHeader.innerHTML = titleName + " | " + rulebaseName;
					
				
				//checks for errors to repeat next to next button
				//this will include both rule errors and question errors 
					if (document.getElementsByClassName("opa-interview-controls")[0].getElementsByTagName("div")[0].getElementsByClassName("opa-error-text").length > 0) {
						//this checks for erros in the div which contains all the questions on one page - any higher causes errors on other pages to be included
						var error = true;
					} else {
						var error = false;
					}
					//to outline next buttons in red if errors on page 
					var submitButtons = document.getElementsByClassName("opa-submit");
					for (i=0;i<submitButtons.length;i++) {
						var thisButton = submitButtons[i];
						thisButton.className = thisButton.className.replace(" errorButton","");
						//thisButton.parentElement.parentElement.className = thisButton.parentElement.parentElement.className.replace(" errorReminder","");
						document.getElementsByClassName("opa-interview-controls")[0].className = document.getElementsByClassName("opa-interview-controls")[0].className.replace(" errorReminder","");
						//removes all added classes then adds them again if needed.
						if (error) {
							thisButton.className += " errorButton"; //class added to all buttons (only affects those of tag <input> in reality)
							thisButton.parentElement.parentElement.className += " errorReminder"; //class added to overall page (for error text beheath buttons)
							thisButton.blur(); // stops focus - otherwise it looks crap in IE
						} 
					}
				
				//to hide "hidden" next buttons - for alignment
				//(this is only needed if the final page has a back button)
					for (i=0;i<submitButtons.length;i++) {
						var thisButton = submitButtons[i];
						if (thisButton.style.visibility == "hidden") {
							thisButton.style.display = "none"; //this removes the button completly, so it doesn't push stuff over.
						} else {
							thisButton.style.display = "block"; //this restores the styling should it have been removed by the above (and then one goes back)
						}
					}
				
				//end of JS titbits
			}
		}
	},
	style: {
		control: function(control) {
			if (control.config.caption.indexOf("HideMe") !== -1) { //this hides questions which have "HideMe" (case-sensative) in the question text
				return {
					style: {
						display:"none",
					}
				}
			}
		},
	    question: function(control) {
			if (control.config.caption.indexOf("HideMe") !== -1 || control.config.caption == 'NoLabel') { //this hides questions which have "HideMe" (case-sensative) in the question text
				return {
					style: {
						display:"none",
					}
				}
			}
			if (!control.isMandatory() && control.config.caption != 'NoLabel') { 
				//this gives optional question text the class "optional" - except those which have no label (their label is "NoLabel")
				return {
					className: "opa-question-optional"
				}
            }
		}
	}
});
