const stage = "Alpha"; //amend for different development stages

if (typeof(document.getElementById("phase-tag")) != 'undefined' && document.getElementById("phase-tag") != null) {
	document.getElementById("phase-tag").innerHTML = stage
}