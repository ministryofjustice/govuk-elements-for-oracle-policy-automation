const stage = "Alpha"; //amend for different development stages

if (stage != "") {
	if (typeof(document.getElementsByClassName("phase-tag")[0]) != 'undefined' && document.getElementsByClassName("phase-tag")[0] != null) {
		document.getElementsByClassName("phase-tag")[0].innerHTML = stage;
	}	
}